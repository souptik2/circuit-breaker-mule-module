package mule.Demo.connectors.internal;


//public class ExtValueProvider implements ValueProvider {
//	
//	private static final Set<Value> extension = ValueBuilder.getValuesFor(new String[]{"zip","gz"});
//
//	   public Set<Value> resolve() throws ValueResolvingException {
//	      return extension;
//	   }
//
//}

public enum ExtValueProvider {
	Miliseconds("Miliseconds"),
	Seconds("Seconds"),
	Minutes("Minutes"),
	Hours("Hours"),
	Days("Days");
	

	   private final String extsn;

	   private ExtValueProvider(String extsn) {
	      this.extsn = extsn;
	   }

	   public String getextsn() {
	      return this.extsn;
	   }
	}
