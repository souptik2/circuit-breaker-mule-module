# Circuitbreaker Extension

Add description ...


...


...


Add this dependency to your application pom.xml

```
<groupId>icoe.mule.connector</groupId>
<artifactId>circuitbreaker</artifactId>
<version>1.0.0</version>
<classifier>mule-plugin</classifier>
```
